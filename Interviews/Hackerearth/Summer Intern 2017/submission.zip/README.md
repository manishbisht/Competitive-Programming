# How to run the project

1. Extract this zip.
2. Open index.html